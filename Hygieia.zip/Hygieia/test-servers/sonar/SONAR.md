The README is in the [gh-pages](https://github.com/capitalone/Hygieia/blob/gh-pages/pages/hygieia/test-servers/test-servers-SONAR.md) branch. Please update it there.
