package com.capitalone.dashboard.uitest;

import net.serenitybdd.jbehave.SerenityStories;

public class UITestRunner extends SerenityStories {

}
