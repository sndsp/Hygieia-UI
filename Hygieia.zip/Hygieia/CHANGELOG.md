# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic
Versioning](http://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [2.0.2] - 2016-09-09
### Added

## [2.0.0] - 2016-04-08
### Added

[Unreleased]: https://github.com/capitalone/Hygieia/compare/v2.0.2...HEAD
[2.0.2]: https://github.com/capitalone/Hygieia/compare/v2.0.0...v2.0.2
[2.0.0]: https://github.com/capitalone/Hygieia/compare/v1.3.0...v2.0.2

