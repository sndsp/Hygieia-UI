import { Component } from '@angular/core';
import {BaseTemplateComponent} from '../../../shared/templates/base-template/base-template.component';

@Component({
  selector: 'app-capone-template',
  templateUrl: './capone-template.component.html',
  styleUrls: ['./capone-template.component.scss']
})
export class CaponeTemplateComponent extends BaseTemplateComponent {
}
