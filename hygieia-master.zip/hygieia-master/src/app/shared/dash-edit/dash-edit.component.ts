import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dash-edit',
  templateUrl: './dash-edit.component.html',
  styleUrls: ['./dash-edit.component.scss']
})
export class DashEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
