import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dash-trash',
  templateUrl: './dash-trash.component.html',
  styleUrls: ['./dash-trash.component.scss']
})
export class DashTrashComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
