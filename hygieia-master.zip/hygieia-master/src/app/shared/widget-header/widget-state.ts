export enum WidgetState {
  READY,
  CONFIGURE,
  WAITING,
  NOT_COLLECTING
}
