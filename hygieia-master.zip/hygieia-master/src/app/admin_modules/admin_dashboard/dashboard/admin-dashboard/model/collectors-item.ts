export class CollectorItem {
    id: string;
    name: string;
    collectorType: string;
    enabled: boolean;
    online: boolean;
    lastExecuted: number;
}
