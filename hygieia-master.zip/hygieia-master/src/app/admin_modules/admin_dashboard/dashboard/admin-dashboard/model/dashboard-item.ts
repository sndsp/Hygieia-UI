export class DashboardItem {
    configurationItemBusAppName: string;
    configurationItemBusServName: string;
    id: string;
    isProduct: boolean;
    name: string;
    scoreDisplay: string;
    scoreEnabled: boolean;
    type: string;
    validAppName: boolean;
    validServiceName: boolean;
}
